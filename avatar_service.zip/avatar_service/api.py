﻿from __future__ import annotations

from fastapi import FastAPI, HTTPException

from avatar_service.config import ConfigurationError, validate_environment
from avatar_service.pipeline.jobs import load_job_status
from avatar_service.pipeline.preprocess import preprocess_avatar
from avatar_service.pipeline.render import render_job
from avatar_service.schemas import (
    EnvironmentValidationResult,
    JobStatusResponse,
    PreprocessAvatarRequest,
    PreprocessAvatarResponse,
    RenderAudioRequest,
    RenderAudioResponse,
    model_to_dict,
)


app = FastAPI(
    title="Avatar Service",
    description="Standalone local MuseTalk service for avatar preprocessing and rendering.",
    version="0.1.0",
)


def _raise_http_error(exc: Exception) -> None:
    if isinstance(exc, FileNotFoundError):
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    if isinstance(exc, (ConfigurationError, RuntimeError)):
        raise HTTPException(status_code=500, detail=str(exc)) from exc
    if isinstance(exc, ValueError):
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    raise HTTPException(status_code=500, detail=str(exc)) from exc


@app.get("/health")
def health_check() -> dict[str, str]:
    return {"status": "ok"}


@app.get("/environment/validate", response_model=EnvironmentValidationResult)
def environment_validate() -> EnvironmentValidationResult:
    return validate_environment()


@app.post("/avatars/preprocess", response_model=PreprocessAvatarResponse)
def preprocess_avatar_endpoint(
    payload: PreprocessAvatarRequest,
) -> PreprocessAvatarResponse:
    try:
        result = preprocess_avatar(
            video_path=payload.video_path,
            avatar_id=payload.avatar_id,
            model_version=payload.model_version,
        )
        return PreprocessAvatarResponse(**model_to_dict(result))
    except Exception as exc:
        _raise_http_error(exc)


@app.post("/jobs/render", response_model=RenderAudioResponse)
def render_audio_endpoint(payload: RenderAudioRequest) -> RenderAudioResponse:
    try:
        result = render_job(
            avatar_id=payload.avatar_id,
            audio_path=payload.audio_path,
            job_id=payload.job_id,
            fps=payload.fps,
            batch_size=payload.batch_size,
            model_version=payload.model_version,
            chunk_duration=payload.chunk_duration,
        )
        return RenderAudioResponse(
            job_id=result.job_id,
            status=result.status,
            output_dir=result.output_dir,
            stream_info_path=result.stream_info_path,
        )
    except Exception as exc:
        _raise_http_error(exc)


@app.get("/jobs/{job_id}", response_model=JobStatusResponse)
def get_job_status(job_id: str) -> JobStatusResponse:
    try:
        return load_job_status(job_id)
    except Exception as exc:
        _raise_http_error(exc)
