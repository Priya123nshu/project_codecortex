﻿from __future__ import annotations

import os
import shutil
import sys
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path

from avatar_service.schemas import EnvironmentCheck, EnvironmentValidationResult


class ConfigurationError(RuntimeError):
    """Raised when the avatar service runtime is not configured correctly."""


@dataclass(frozen=True)
class ModelPaths:
    unet_model_path: Path
    unet_config: Path
    whisper_dir: Path


def _load_dotenv() -> None:
    """Load a simple .env file without requiring extra dependencies."""
    candidate_paths = [
        Path.cwd() / ".env",
        Path(__file__).resolve().parent / ".env",
    ]

    for env_path in candidate_paths:
        if not env_path.exists():
            continue

        for raw_line in env_path.read_text(encoding="utf-8").splitlines():
            line = raw_line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue

            key, value = line.split("=", 1)
            key = key.strip().lstrip("\ufeff")
            value = value.strip().strip("'").strip('"')
            if key and key not in os.environ:
                os.environ[key] = value
        break


def _path_from_env(name: str, default: Path, *, base_dir: Path) -> Path:
    raw_value = os.getenv(name)
    path = Path(raw_value).expanduser() if raw_value else default
    if not path.is_absolute():
        path = (base_dir / path).resolve()
    return path


@dataclass(frozen=True)
class Settings:
    service_root: Path
    muse_talk_repo_dir: Path
    model_root: Path
    work_root: Path
    avatar_root: Path
    jobs_root: Path
    output_root: Path
    default_model_version: str
    default_fps: int
    default_batch_size: int
    ffmpeg_bin: str

    @classmethod
    def from_env(cls) -> "Settings":
        _load_dotenv()

        service_root = Path(__file__).resolve().parent
        work_root = _path_from_env("WORK_ROOT", service_root, base_dir=service_root)
        avatar_root = _path_from_env(
            "AVATAR_ROOT",
            work_root / "storage" / "avatars",
            base_dir=service_root,
        )
        jobs_root = _path_from_env(
            "JOBS_ROOT",
            work_root / "storage" / "jobs",
            base_dir=service_root,
        )
        output_root = _path_from_env(
            "OUTPUT_ROOT",
            work_root / "storage" / "outputs",
            base_dir=service_root,
        )

        settings = cls(
            service_root=service_root,
            muse_talk_repo_dir=_path_from_env(
                "MUSE_TALK_REPO_DIR",
                Path("~/MuseTalk").expanduser(),
                base_dir=service_root,
            ),
            model_root=_path_from_env(
                "MODEL_ROOT",
                Path("~/models/musetalk").expanduser(),
                base_dir=service_root,
            ),
            work_root=work_root,
            avatar_root=avatar_root,
            jobs_root=jobs_root,
            output_root=output_root,
            default_model_version=os.getenv("DEFAULT_MODEL_VERSION", "v15"),
            default_fps=int(os.getenv("DEFAULT_FPS", "25")),
            default_batch_size=int(os.getenv("DEFAULT_BATCH_SIZE", "8")),
            ffmpeg_bin=os.getenv("FFMPEG_BIN", "ffmpeg"),
        )
        settings.ensure_storage_dirs()
        return settings

    def ensure_storage_dirs(self) -> None:
        for path in (self.avatar_root, self.jobs_root, self.output_root):
            path.mkdir(parents=True, exist_ok=True)

    def require_directory(self, path: Path, label: str) -> Path:
        if not path.exists():
            raise ConfigurationError(f"{label} does not exist: {path}")
        if not path.is_dir():
            raise ConfigurationError(f"{label} is not a directory: {path}")
        return path

    def require_file(self, path: Path, label: str) -> Path:
        if not path.exists():
            raise ConfigurationError(f"{label} does not exist: {path}")
        if not path.is_file():
            raise ConfigurationError(f"{label} is not a file: {path}")
        return path

    def require_musetalk_repo(self) -> Path:
        return self.require_directory(self.muse_talk_repo_dir, "MUSE_TALK_REPO_DIR")

    def require_model_root(self) -> Path:
        return self.require_directory(self.model_root, "MODEL_ROOT")

    def resolve_ffmpeg_bin(self) -> str:
        ffmpeg_path = Path(self.ffmpeg_bin)
        if ffmpeg_path.is_absolute():
            if not ffmpeg_path.exists():
                raise ConfigurationError(f"FFMPEG_BIN does not exist: {ffmpeg_path}")
            return str(ffmpeg_path)

        resolved = shutil.which(self.ffmpeg_bin)
        if not resolved:
            raise ConfigurationError(
                f"Could not find ffmpeg executable on PATH: {self.ffmpeg_bin}"
            )
        return resolved

    def resolve_ffprobe_bin(self) -> str:
        ffmpeg_bin = self.resolve_ffmpeg_bin()
        ffmpeg_path = Path(ffmpeg_bin)

        if ffmpeg_path.name.startswith("ffmpeg"):
            sibling_name = ffmpeg_path.name.replace("ffmpeg", "ffprobe", 1)
            sibling_path = ffmpeg_path.with_name(sibling_name)
            if sibling_path.exists():
                return str(sibling_path)

        resolved = shutil.which("ffprobe")
        if not resolved:
            raise ConfigurationError(
                "Could not find ffprobe executable on PATH. Install ffmpeg/ffprobe first."
            )
        return resolved

    def resolve_model_paths(self, model_version: str | None = None) -> ModelPaths:
        version = model_version or self.default_model_version
        if version not in {"v1", "v15"}:
            raise ValueError(f"Unsupported model version: {version}")

        model_root = self.require_model_root()
        if version == "v15":
            unet_model_path = model_root / "musetalkV15" / "unet.pth"
            unet_config = model_root / "musetalkV15" / "musetalk.json"
        else:
            unet_model_path = model_root / "musetalk" / "pytorch_model.bin"
            unet_config = model_root / "musetalk" / "musetalk.json"

        whisper_dir = model_root / "whisper"

        self.require_file(unet_model_path, "MuseTalk UNet weights")
        self.require_file(unet_config, "MuseTalk config")
        self.require_directory(whisper_dir, "Whisper model directory")

        return ModelPaths(
            unet_model_path=unet_model_path,
            unet_config=unet_config,
            whisper_dir=whisper_dir,
        )


def validate_environment(settings: Settings | None = None) -> EnvironmentValidationResult:
    active_settings = settings or get_settings()
    checks: list[EnvironmentCheck] = []

    python_version = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
    if sys.version_info[:2] == (3, 10):
        checks.append(
            EnvironmentCheck(
                name="python_version",
                status="ok",
                detail=f"Python {python_version} detected.",
            )
        )
    else:
        checks.append(
            EnvironmentCheck(
                name="python_version",
                status="warning",
                detail=(
                    f"Python {python_version} detected. Python 3.10 is recommended "
                    "for MuseTalk compatibility."
                ),
            )
        )

    try:
        ffmpeg_bin = active_settings.resolve_ffmpeg_bin()
        checks.append(
            EnvironmentCheck(
                name="ffmpeg",
                status="ok",
                detail=f"ffmpeg found at {ffmpeg_bin}",
            )
        )
    except Exception as exc:
        checks.append(EnvironmentCheck(name="ffmpeg", status="error", detail=str(exc)))

    try:
        ffprobe_bin = active_settings.resolve_ffprobe_bin()
        checks.append(
            EnvironmentCheck(
                name="ffprobe",
                status="ok",
                detail=f"ffprobe found at {ffprobe_bin}",
            )
        )
    except Exception as exc:
        checks.append(EnvironmentCheck(name="ffprobe", status="error", detail=str(exc)))

    repo_dir = active_settings.muse_talk_repo_dir
    if repo_dir.exists() and repo_dir.is_dir():
        package_path = repo_dir / "musetalk" / "utils" / "utils.py"
        if package_path.exists():
            checks.append(
                EnvironmentCheck(
                    name="musetalk_repo",
                    status="ok",
                    detail=f"MuseTalk repo found at {repo_dir}",
                )
            )
        else:
            checks.append(
                EnvironmentCheck(
                    name="musetalk_repo",
                    status="error",
                    detail=(
                        f"Directory exists but does not look like a MuseTalk checkout: {repo_dir}"
                    ),
                )
            )
    else:
        checks.append(
            EnvironmentCheck(
                name="musetalk_repo",
                status="error",
                detail=f"MUSE_TALK_REPO_DIR does not exist: {repo_dir}",
            )
        )

    model_root = active_settings.model_root
    if model_root.exists() and model_root.is_dir():
        try:
            model_paths = active_settings.resolve_model_paths()
            checks.append(
                EnvironmentCheck(
                    name="model_root",
                    status="ok",
                    detail=f"Model root verified at {model_root}",
                )
            )
            checks.append(
                EnvironmentCheck(
                    name="unet_model",
                    status="ok",
                    detail=f"UNet weights found at {model_paths.unet_model_path}",
                )
            )
            checks.append(
                EnvironmentCheck(
                    name="whisper_model",
                    status="ok",
                    detail=f"Whisper model directory found at {model_paths.whisper_dir}",
                )
            )
        except Exception as exc:
            checks.append(EnvironmentCheck(name="model_root", status="error", detail=str(exc)))
    else:
        checks.append(
            EnvironmentCheck(
                name="model_root",
                status="error",
                detail=f"MODEL_ROOT does not exist: {model_root}",
            )
        )

    for name, path in {
        "avatar_root": active_settings.avatar_root,
        "jobs_root": active_settings.jobs_root,
        "output_root": active_settings.output_root,
    }.items():
        checks.append(
            EnvironmentCheck(
                name=name,
                status="ok",
                detail=f"Storage directory ready at {path}",
            )
        )

    statuses = {check.status for check in checks}
    if "error" in statuses:
        overall_status = "error"
    elif "warning" in statuses:
        overall_status = "warning"
    else:
        overall_status = "ok"

    return EnvironmentValidationResult(overall_status=overall_status, checks=checks)


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings.from_env()


